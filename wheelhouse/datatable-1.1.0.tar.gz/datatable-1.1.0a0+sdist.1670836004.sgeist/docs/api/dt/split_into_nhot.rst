
.. xfunction:: datatable.split_into_nhot
    :src: --
    :cvar: doc_dt_split_into_nhot
    :signature: split_into_nhot(frame, sep=",", sort=False)

    .. x-version-deprecated:: 1.0.0

        This function is deprecated and will be removed in version 1.1.0.
        Please use :func:`dt.str.split_into_nhot()` instead.
