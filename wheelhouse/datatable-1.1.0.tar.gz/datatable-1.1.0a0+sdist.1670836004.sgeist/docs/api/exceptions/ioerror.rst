
.. xexc:: datatable.exceptions.IOError
    :src: --

    Raised during any IO operation, such as reading/writing CSV or Jay files.
    The most common cause for such an error is an invalid input file.

    Inherits from Python :py:exc:`IOError` and :exc:`datatable.exceptions.DtException`.
