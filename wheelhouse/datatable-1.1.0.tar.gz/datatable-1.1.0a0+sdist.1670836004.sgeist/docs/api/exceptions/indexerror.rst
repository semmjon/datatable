
.. xexc:: datatable.exceptions.IndexError
    :src: --

    Raised when accessing an element of a frame by index, but the value of the
    index falls outside of the boundaries of the frame.

    Inherits from Python :py:exc:`IndexError` and :exc:`datatable.exceptions.DtException`.
