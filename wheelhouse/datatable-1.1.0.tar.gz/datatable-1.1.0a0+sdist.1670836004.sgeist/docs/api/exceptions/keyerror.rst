
.. xexc:: datatable.exceptions.KeyError
    :src: --

    Raised when accessing a column of a frame by name, but the name lookup
    fails to find such a column.

    Inherits from Python :py:exc:`KeyError` and :exc:`datatable.exceptions.DtException`.
