
.. xexc:: datatable.exceptions.NotImplementedError
    :src: --

    Raised whenever an operation with given parameter values or input types
    is in theory valid, but hasn't been implemented yet.

    Inherits from Python :py:exc:`NotImplementedError` and :exc:`datatable.exceptions.DtException`.
