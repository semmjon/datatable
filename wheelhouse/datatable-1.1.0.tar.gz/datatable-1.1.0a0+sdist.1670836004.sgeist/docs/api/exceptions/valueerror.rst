
.. xexc:: datatable.exceptions.ValueError
    :src: --

    Very common exception that occurs whenever an argument is passed to a
    function and that argument has the correct type, yet the value is
    not valid.

    Inherits from Python :py:exc:`ValueError` and :exc:`datatable.exceptions.DtException`.
