
.. xexc:: datatable.exceptions.IOWarning
    :src: --

    This warning is raised whenever you read an input file and there are some
    irregularities in the input that we can recover from, but perhaps the user
    should be informed that something wasn't quite right.
