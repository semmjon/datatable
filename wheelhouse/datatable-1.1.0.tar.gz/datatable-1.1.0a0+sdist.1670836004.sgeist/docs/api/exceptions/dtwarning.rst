
.. xexc:: datatable.exceptions.DatatableWarning
    :src: --

    Generic warning from the :mod:`datatable`.
