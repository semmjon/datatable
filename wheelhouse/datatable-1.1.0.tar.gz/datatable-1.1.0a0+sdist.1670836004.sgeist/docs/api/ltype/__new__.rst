
.. xmethod:: datatable.ltype.__new__
    :src: src/datatable/types.py ___new___

    __new__(self, value)
    --

    Find an ltype corresponding to `value`.

    This method is similar to :meth:`dt.stype.__new__()`, except that it
    returns an ltype instead of an stype.
