
.. xmethod:: datatable.ltype.stypes
    :src: src/datatable/types.py stypes
