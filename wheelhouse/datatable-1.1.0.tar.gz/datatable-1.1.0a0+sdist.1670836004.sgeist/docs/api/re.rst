
.. xpy:module:: datatable.re

datatable.re
=============

.. list-table::
   :widths: auto
   :class: api-table

   * - :func:`match()`
     - Search for a regular expression within a column.



.. toctree::
    :hidden:

    match()          <re/match>
