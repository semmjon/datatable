
.. xfunction:: datatable.math.sqrt
    :src: src/core/expr/funary/exponential.cc resolve_op_sqrt
    :cvar: doc_math_sqrt
    :signature: sqrt(x)

    The square root of x, same as ``x ** 0.5``.
