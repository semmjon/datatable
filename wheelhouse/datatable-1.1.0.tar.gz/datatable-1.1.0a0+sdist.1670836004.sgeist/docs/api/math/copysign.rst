
.. xfunction:: datatable.math.copysign
    :src: src/core/expr/fbinary/math.cc resolve_fn_copysign
    :cvar: doc_math_copysign
    :signature: copysign(x, y)

    Return a float with the magnitude of ``x`` and the sign of ``y``.
