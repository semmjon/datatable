
.. xfunction:: datatable.math.cbrt
    :src: src/core/expr/funary/exponential.cc resolve_op_cbrt
    :cvar: doc_math_cbrt
    :signature: cbrt(x)

    Cubic root of x.
