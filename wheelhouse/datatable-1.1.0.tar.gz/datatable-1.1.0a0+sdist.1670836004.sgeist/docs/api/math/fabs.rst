
.. xfunction:: datatable.math.fabs
    :src: src/core/expr/funary/floating.cc resolve_op_fabs
    :cvar: doc_math_fabs
    :signature: fabs(x)

    The absolute value of `x`, returned as float.
