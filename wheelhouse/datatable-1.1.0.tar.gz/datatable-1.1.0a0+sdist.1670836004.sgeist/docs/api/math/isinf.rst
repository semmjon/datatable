
.. xfunction:: datatable.math.isinf
    :src: src/core/expr/funary/floating.cc resolve_op_isinf
    :cvar: doc_math_isinf
    :signature: isinf(x)

    Returns True if the argument is +/- infinity, and False otherwise.
    Note that `isinf(NA) == False`.
