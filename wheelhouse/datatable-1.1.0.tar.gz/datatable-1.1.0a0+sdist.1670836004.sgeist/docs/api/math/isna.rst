
.. xfunction:: datatable.math.isna
    :src: src/core/expr/funary/floating.cc resolve_op_isna
    :tests: tests/math/test-isna.py
    :cvar: doc_math_isna
    :signature: isna(x)

    Returns `True` if the argument is NA, and `False` otherwise.
