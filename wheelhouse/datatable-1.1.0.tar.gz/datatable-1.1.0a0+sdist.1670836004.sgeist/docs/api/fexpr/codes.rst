
.. xmethod:: datatable.FExpr.codes
    :src: src/core/expr/fexpr.cc PyFExpr::codes
    :cvar: doc_FExpr_codes
    :signature: codes()

    Equivalent to :func:`dt.codes(cols)`.
