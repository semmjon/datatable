
.. xmethod:: datatable.FExpr.rowmin
    :src: src/core/expr/fexpr.cc PyFExpr::rowmin
    :cvar: doc_FExpr_rowmin
    :signature: rowmin()

    Equivalent to :func:`dt.rowmin(*cols)`.
