
.. xmethod:: datatable.FExpr.mean
    :src: src/core/expr/fexpr.cc PyFExpr::mean
    :cvar: doc_FExpr_mean
    :signature: mean()

    Equivalent to :func:`dt.mean(cols)`.
