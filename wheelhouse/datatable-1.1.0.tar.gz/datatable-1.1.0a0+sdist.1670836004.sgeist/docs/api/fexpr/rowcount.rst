
.. xmethod:: datatable.FExpr.rowcount
    :src: src/core/expr/fexpr.cc PyFExpr::rowcount
    :cvar: doc_FExpr_rowcount
    :signature: rowcount()

    Equivalent to :func:`dt.rowcount(*cols)`.
