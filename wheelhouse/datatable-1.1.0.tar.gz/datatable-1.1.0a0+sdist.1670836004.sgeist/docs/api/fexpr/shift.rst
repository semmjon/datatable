
.. xmethod:: datatable.FExpr.shift
    :src: src/core/expr/fexpr.cc PyFExpr::shift
    :cvar: doc_FExpr_shift
    :signature: shift(n=1)

    Equivalent to :func:`dt.shift(cols, n=1)`.
