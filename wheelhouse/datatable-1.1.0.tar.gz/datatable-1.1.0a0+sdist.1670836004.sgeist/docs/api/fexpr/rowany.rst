
.. xmethod:: datatable.FExpr.rowany
    :src: src/core/expr/fexpr.cc PyFExpr::rowany
    :cvar: doc_FExpr_rowany
    :signature: rowany()

    Equivalent to :func:`dt.rowany(*cols)`.
