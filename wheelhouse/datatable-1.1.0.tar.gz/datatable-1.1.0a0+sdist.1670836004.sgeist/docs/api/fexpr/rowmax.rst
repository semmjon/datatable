
.. xmethod:: datatable.FExpr.rowmax
    :src: src/core/expr/fexpr.cc PyFExpr::rowmax
    :cvar: doc_FExpr_rowmax
    :signature: rowmax()

    Equivalent to :func:`dt.rowmax(*cols)`.
