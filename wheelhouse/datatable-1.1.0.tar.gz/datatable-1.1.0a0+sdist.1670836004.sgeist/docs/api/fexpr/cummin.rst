
.. xmethod:: datatable.FExpr.cummin
    :src: src/core/expr/fexpr.cc PyFExpr::cummin
    :cvar: doc_FExpr_cummin
    :signature: cummin()

    Equivalent to :func:`dt.cummin(cols)`.
