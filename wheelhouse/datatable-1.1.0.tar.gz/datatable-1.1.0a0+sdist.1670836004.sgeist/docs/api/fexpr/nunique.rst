
.. xmethod:: datatable.FExpr.nunique
    :src: src/core/expr/fexpr.cc PyFExpr::nunique
    :cvar: doc_FExpr_nunique
    :signature: nunique()

    Equivalent to :func:`dt.nunique(cols)`.
