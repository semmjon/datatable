
.. xmethod:: datatable.FExpr.prod
    :src: src/core/expr/fexpr.cc PyFExpr::prod
    :cvar: doc_FExpr_prod
    :signature: prod()

    .. x-version-added:: 1.1.0

    Equivalent to :func:`dt.prod(cols)`.

