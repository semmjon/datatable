
.. xmethod:: datatable.FExpr.count
    :src: src/core/expr/fexpr.cc PyFExpr::count
    :cvar: doc_FExpr_count
    :signature: count()

    Equivalent to :func:`dt.count(cols)`.
