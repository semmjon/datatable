
.. xmethod:: datatable.FExpr.len
    :src: --
    :signature: len(self)

    .. x-version-deprecated:: 0.11

        This method is deprecated and will be removed in version 1.1.0.
        Please use :func:`dt.str.len()` instead.
