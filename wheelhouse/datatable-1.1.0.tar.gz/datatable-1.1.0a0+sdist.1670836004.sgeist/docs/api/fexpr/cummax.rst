
.. xmethod:: datatable.FExpr.cummax
    :src: src/core/expr/fexpr.cc PyFExpr::cummax
    :cvar: doc_FExpr_cummax
    :signature: cummax()

    Equivalent to :func:`dt.cummax(cols)`.
