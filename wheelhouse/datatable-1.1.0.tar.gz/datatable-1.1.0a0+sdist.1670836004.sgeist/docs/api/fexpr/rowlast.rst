
.. xmethod:: datatable.FExpr.rowlast
    :src: src/core/expr/fexpr.cc PyFExpr::rowlast
    :cvar: doc_FExpr_rowlast
    :signature: rowlast()

    Equivalent to :func:`dt.rowlast(*cols)`.
