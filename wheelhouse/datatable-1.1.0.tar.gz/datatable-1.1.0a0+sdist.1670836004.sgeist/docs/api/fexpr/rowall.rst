
.. xmethod:: datatable.FExpr.rowall
    :src: src/core/expr/fexpr.cc PyFExpr::rowall
    :cvar: doc_FExpr_rowall
    :signature: rowall()

    Equivalent to :func:`dt.rowall(*cols)`.
