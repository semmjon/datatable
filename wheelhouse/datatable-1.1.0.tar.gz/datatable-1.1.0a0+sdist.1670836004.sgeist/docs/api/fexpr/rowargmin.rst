
.. xmethod:: datatable.FExpr.rowargmin
    :src: src/core/expr/fexpr.cc PyFExpr::rowargmin
    :cvar: doc_FExpr_rowargmin
    :signature: rowargmin()

    .. x-version-added:: 1.1.0

    Equivalent to :func:`dt.rowargmin(*cols)`.
