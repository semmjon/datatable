
.. xmethod:: datatable.FExpr.as_type
    :src: src/core/expr/fexpr.cc PyFExpr::as_type
    :cvar: doc_FExpr_as_type
    :signature: as_type(new_type)

    .. x-version-added:: 1.1.0

    Equivalent to :func:`dt.as_type(cols, new_type)`.

