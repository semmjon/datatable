
.. xmethod:: datatable.FExpr.min
    :src: src/core/expr/fexpr.cc PyFExpr::min
    :cvar: doc_FExpr_min
    :signature: min()

    Equivalent to :func:`dt.min(cols)`.
