
.. xmethod:: datatable.FExpr.fillna
    :src: src/core/expr/fexpr.cc PyFExpr::fillna
    :cvar: doc_FExpr_fillna
    :signature: fillna(reverse=False)

    Equivalent to :func:`dt.fillna(cols, reverse=False)`.
