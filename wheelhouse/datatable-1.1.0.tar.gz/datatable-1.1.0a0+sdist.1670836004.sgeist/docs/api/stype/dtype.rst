
.. xattr:: datatable.stype.dtype
    :src: src/datatable/types.py dtype
