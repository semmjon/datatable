
.. xattr:: datatable.stype.max
    :src: src/datatable/types.py max
