
.. xattr:: datatable.stype.ltype
    :src: src/datatable/types.py ltype
