
.. xattr:: datatable.options.fread.parse_times
    :src: --
    :cvar: doc_options_fread_parse_times
    :settable: value

    If True, fread will attempt to detect columns of time64 type. If False,
    then columns with timestamps will be returned as strings.

    .. warning::

        This option is temporary and will be removed in the future.
