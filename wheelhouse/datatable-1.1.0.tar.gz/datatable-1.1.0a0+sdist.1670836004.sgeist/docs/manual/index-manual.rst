
User Guide
==========

.. toctree::

    name_mangling
    f-expressions
    fread_examples
    select_and_filter_data
    transform_data
    groupby_examples
    row_functions
    comparison_with_pandas
    comparison_with_rdatatable
    comparison_with_sql
    datetime
    ftrl
