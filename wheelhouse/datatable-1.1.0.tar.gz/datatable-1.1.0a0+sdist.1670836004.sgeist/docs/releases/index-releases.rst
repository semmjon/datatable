
Release History
===============


.. toctree::
    :maxdepth: 1

    Under development  <v1.1.0>
    v1.0.0
    v0.11.1
    v0.11.0
    v0.10.1
    v0.10.0
    v0.9.0
    v0.8.0
    v0.7.0
    v0.6.0
    v0.5.0
    v0.4.0
    v0.3.2
    v0.3.1
    v0.3.0
    v0.2.2
    v0.2.1
    contributors
