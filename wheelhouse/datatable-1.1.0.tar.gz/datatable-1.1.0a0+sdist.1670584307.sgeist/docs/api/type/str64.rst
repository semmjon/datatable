
.. xattr:: datatable.Type.str64
    :src: --
    :tests: tests/types/test-str.py

    String type, where the offsets buffer uses 64-bit integers.
