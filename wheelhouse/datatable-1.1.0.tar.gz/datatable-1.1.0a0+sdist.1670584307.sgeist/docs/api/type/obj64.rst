
.. xattr:: datatable.Type.obj64
    :src: --
    :tests: tests/types/test-obj64.py

    This type can be used to store arbitrary Python objects.
