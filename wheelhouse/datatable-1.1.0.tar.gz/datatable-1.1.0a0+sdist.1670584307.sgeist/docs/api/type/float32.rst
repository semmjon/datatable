
.. xattr:: datatable.Type.float32
    :src: --
    :tests: tests/types/test-float.py

    Single-precision floating point type. This corresponds to C type ``float``.
    Each element of this type is 4 bytes long.
