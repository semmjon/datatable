
.. xattr:: datatable.Type.float64
    :src: --
    :tests: tests/types/test-float.py

    Double-precision IEEE-754 floating point type. This corresponds to C type
    ``double``. Each element of this type is 8 bytes long.
