
.. xexc:: datatable.exceptions.DtException
    :src: --

    Base class for all exceptions raised by ``datatable``.
