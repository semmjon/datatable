
.. xexc:: datatable.exceptions.MemoryError
    :src: --

    This exception is raised whenever any operation fails to allocate the
    required amount of memory.

    Inherits from Python :py:exc:`MemoryError` and :exc:`datatable.exceptions.DtException`.
