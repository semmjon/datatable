
.. xdata:: datatable.math.inf
    :src: src/datatable/math.py inf

    Number representing positive infinity :math:`\infty`. Write ``-inf`` for
    negative infinity.
