
.. xfunction:: datatable.math.rint
    :src: src/core/expr/funary/floating.cc resolve_op_rint
    :cvar: doc_math_rint
    :signature: rint(x)

    Round the value `x` to the nearest integer.
