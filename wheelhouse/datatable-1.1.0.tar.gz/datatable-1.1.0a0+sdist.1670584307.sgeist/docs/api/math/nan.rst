
.. xdata:: datatable.math.nan
    :src: src/datatable/math.py nan

    Not-a-number, a special floating-point constant that denotes a missing
    number. In most datatable functions you can use ``None`` instead
    of ``nan``.
