
.. xfunction:: datatable.math.lgamma
    :src: src/core/expr/funary/special.cc resolve_op_lgamma
    :cvar: doc_math_lgamma
    :signature: lgamma(x)

    Natural logarithm of the absolute value of the Euler Gamma
    function of `x`.
