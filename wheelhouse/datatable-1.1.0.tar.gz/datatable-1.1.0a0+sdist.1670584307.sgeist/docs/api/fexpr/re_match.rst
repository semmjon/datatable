
.. xmethod:: datatable.FExpr.re_match
    :src: --
    :signature: re_match(self, pattern)

    .. x-version-deprecated:: 1.0.0

        This method is deprecated and will be removed in version 1.1.0.
        Please use :func:`dt.re.match()` instead.
