
.. xmethod:: datatable.FExpr.max
    :src: src/core/expr/fexpr.cc PyFExpr::max
    :cvar: doc_FExpr_max
    :signature: max()

    Equivalent to :func:`dt.max(cols)`.
