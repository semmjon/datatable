
.. xmethod:: datatable.FExpr.sum
    :src: src/core/expr/fexpr.cc PyFExpr::sum
    :cvar: doc_FExpr_sum
    :signature: sum()

    Equivalent to :func:`dt.sum(cols)`.
