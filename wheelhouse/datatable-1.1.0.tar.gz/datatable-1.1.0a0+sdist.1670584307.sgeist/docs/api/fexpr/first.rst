
.. xmethod:: datatable.FExpr.first
    :src: src/core/expr/fexpr.cc PyFExpr::first
    :cvar: doc_FExpr_first
    :signature: first()

    Equivalent to :func:`dt.first(cols)`.
