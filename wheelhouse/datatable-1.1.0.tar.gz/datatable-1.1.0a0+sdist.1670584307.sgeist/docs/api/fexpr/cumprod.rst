
.. xmethod:: datatable.FExpr.cumprod
    :src: src/core/expr/fexpr.cc PyFExpr::cumprod
    :cvar: doc_FExpr_cumprod
    :signature: cumprod()

    Equivalent to :func:`dt.cumprod(cols)`.

