
.. xmethod:: datatable.FExpr.rowargmax
    :src: src/core/expr/fexpr.cc PyFExpr::rowargmax
    :cvar: doc_FExpr_rowargmax
    :signature: rowargmax()

    .. x-version-added:: 1.1.0

    Equivalent to :func:`dt.rowargmax(*cols)`.
