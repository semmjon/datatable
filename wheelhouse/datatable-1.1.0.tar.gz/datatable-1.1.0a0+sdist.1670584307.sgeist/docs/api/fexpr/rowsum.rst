
.. xmethod:: datatable.FExpr.rowsum
    :src: src/core/expr/fexpr.cc PyFExpr::rowsum
    :cvar: doc_FExpr_rowsum
    :signature: rowsum()

    Equivalent to :func:`dt.rowsum(*cols)`.
