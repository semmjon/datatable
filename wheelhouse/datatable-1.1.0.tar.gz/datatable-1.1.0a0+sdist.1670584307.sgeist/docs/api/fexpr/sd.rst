
.. xmethod:: datatable.FExpr.sd
    :src: src/core/expr/fexpr.cc PyFExpr::sd
    :cvar: doc_FExpr_sd
    :signature: sd()

    Equivalent to :func:`dt.sd(cols)`.
