
.. xmethod:: datatable.FExpr.rowsd
    :src: src/core/expr/fexpr.cc PyFExpr::rowsd
    :cvar: doc_FExpr_rowsd
    :signature: rowsd()

    Equivalent to :func:`dt.rowsd(*cols)`.
