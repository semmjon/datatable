
.. xmethod:: datatable.FExpr.rowfirst
    :src: src/core/expr/fexpr.cc PyFExpr::rowfirst
    :cvar: doc_FExpr_rowfirst
    :signature: rowfirst()

    Equivalent to :func:`dt.rowfirst(*cols)`.
