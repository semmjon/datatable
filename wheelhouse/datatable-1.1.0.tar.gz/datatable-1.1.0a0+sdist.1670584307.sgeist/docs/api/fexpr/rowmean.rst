
.. xmethod:: datatable.FExpr.rowmean
    :src: src/core/expr/fexpr.cc PyFExpr::rowmean
    :cvar: doc_FExpr_rowmean
    :signature: rowmean()

    Equivalent to :func:`dt.rowmean(*cols)`.
