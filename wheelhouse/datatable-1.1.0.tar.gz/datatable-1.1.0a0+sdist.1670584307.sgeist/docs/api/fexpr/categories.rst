
.. xmethod:: datatable.FExpr.categories
    :src: src/core/expr/fexpr.cc PyFExpr::categories
    :cvar: doc_FExpr_categories
    :signature: categories()

    Equivalent to :func:`dt.categories(cols)`.
