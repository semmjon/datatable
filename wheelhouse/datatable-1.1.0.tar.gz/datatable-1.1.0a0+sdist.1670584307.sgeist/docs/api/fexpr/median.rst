
.. xmethod:: datatable.FExpr.median
    :src: src/core/expr/fexpr.cc PyFExpr::median
    :cvar: doc_FExpr_median
    :signature: median()

    Equivalent to :func:`dt.median(cols)`.
