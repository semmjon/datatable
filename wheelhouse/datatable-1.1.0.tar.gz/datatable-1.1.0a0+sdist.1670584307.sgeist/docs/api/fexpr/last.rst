
.. xmethod:: datatable.FExpr.last
    :src: src/core/expr/fexpr.cc PyFExpr::last
    :cvar: doc_FExpr_last
    :signature: last()

    Equivalent to :func:`dt.last(cols)`.
