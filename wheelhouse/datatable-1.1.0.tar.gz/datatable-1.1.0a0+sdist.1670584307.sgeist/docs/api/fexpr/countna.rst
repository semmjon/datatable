
.. xmethod:: datatable.FExpr.countna
    :src: src/core/expr/fexpr.cc PyFExpr::countna
    :cvar: doc_FExpr_countna
    :signature: countna()

    Equivalent to :func:`dt.countna(cols)`.
