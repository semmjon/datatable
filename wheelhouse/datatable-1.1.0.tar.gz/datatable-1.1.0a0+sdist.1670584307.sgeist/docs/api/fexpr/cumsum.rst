
.. xmethod:: datatable.FExpr.cumsum
    :src: src/core/expr/fexpr.cc PyFExpr::cumsum
    :cvar: doc_FExpr_cumsum
    :signature: cumsum()

    Equivalent to :func:`dt.cumsum(cols)`.
