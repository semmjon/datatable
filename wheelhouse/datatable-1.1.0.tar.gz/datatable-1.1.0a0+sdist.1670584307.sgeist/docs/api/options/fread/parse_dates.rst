
.. xattr:: datatable.options.fread.parse_dates
    :src: --
    :cvar: doc_options_fread_parse_dates
    :settable: value

    If True, fread will attempt to detect columns of date32 type. If False,
    then columns with date values will be returned as strings.

    .. warning::

        This option is temporary and will be removed in the future.
