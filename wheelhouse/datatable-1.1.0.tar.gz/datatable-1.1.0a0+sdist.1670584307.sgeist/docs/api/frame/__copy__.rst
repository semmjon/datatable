
.. xmethod:: datatable.Frame.__copy__
    :src: src/core/frame/py_frame.cc Frame::m__copy__

    This method facilitates copying of a Frame via the python standard module
    ``copy``. See :meth:`.copy()` for more details.

