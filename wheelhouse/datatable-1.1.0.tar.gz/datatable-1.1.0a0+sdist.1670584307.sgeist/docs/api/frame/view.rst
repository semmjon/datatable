
.. xmethod:: datatable.Frame.view
    :src: src/core/frame/__repr__.cc Frame::view
    :cvar: doc_Frame_view
    :signature: view(self, interactive=None, plain=False)

    .. warning::

        This function is currently not working properly.
        `[#2669] <https://github.com/h2oai/datatable/issues/2669>`_
