
.. xattr:: datatable.stype.struct
    :src: src/datatable/types.py struct
