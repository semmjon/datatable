
.. xattr:: datatable.stype.ctype
    :src: src/datatable/types.py ctype
