
.. xattr:: datatable.stype.min
    :src: src/datatable/types.py min
